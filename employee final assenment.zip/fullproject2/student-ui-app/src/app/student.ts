export class Student {
    id: number;
    name: string;

   salary: number;
    deg: string;
    addr: string;
}
